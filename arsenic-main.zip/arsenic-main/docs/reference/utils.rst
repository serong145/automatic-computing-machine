``arsenic.utils``
#################


.. py:module:: arsenic.utils

.. py:function:: free_port

    Returns a free port.

    :rtype: int


.. py:class:: Rect

    .. py:attribute:: x
    .. py:attribute:: y
    .. py:attribute:: width
    .. py:attribute:: height
