# Changelog

## 20.9

* Added Changelog
* Added support for async script execution
* Added support for taking screenshots of elements
* Added support for setting HttpOnly cookies
* Added support for maximizing and fullscreening the window
* Added support for setting a timeout on the get API
* Added support for new geckodriver
* Added support for (chromium) Edge
* Fixed floating point pixel values
* arsenic now always uses the W3C webdriver protocol, the selenium protocol is no longer supported
* Removed support for PhantomJS
* Removed CompatSession/CompatElement

